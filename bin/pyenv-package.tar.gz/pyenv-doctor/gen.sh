#!/bin/sh -e
autoreconf
